#--------------------------------#
#       GNOME Home Manager
#--------------------------------#

{ config, pkgs, ... }:

{ 
  #--------------------------------#
  #  Set Wallpaper & Lock Screen
  #--------------------------------#
  # Copy wallpaper into ~/Pictures
  home.file."Pictures/Wallpapers/blue-landscape.png".source =
    ../../users/fuzzles/assets/wallpapers/blue-landscape.png;

  #--------------------------------#
  #     Packages (user-level)
  #--------------------------------#
  home.packages = with pkgs; [
    # Applications
    gnome-tweaks           # GNOME Tweaks
    ignition               # GNOME Startup
    pika-backup            # Backup GUI Tool
    impression             # ISO Image Writer
    dconf-editor           # GUI dconf Configuration

    # GNOME Extensions
    gnomeExtensions.appindicator
    gnomeExtensions.blur-my-shell
    gnomeExtensions.dash-to-dock
    gnomeExtensions.caffeine
    gnomeExtensions.gsconnect
    gnomeExtensions.edit-desktop-files
    gnomeExtensions.system-monitor
  ];

    #--------------------------------#
    #     dconf / GNOME settings
    #--------------------------------#
    dconf = {
    enable = true;
    settings = {
      "org/gnome/shell" = {
        disable-user-extensions = false;
        enabled-extensions = with pkgs.gnomeExtensions; [
          appindicator.extensionUuid
          blur-my-shell.extensionUuid
          dash-to-dock.extensionUuid
          caffeine.extensionUuid
          gsconnect.extensionUuid     
          edit-desktop-files.extensionUuid
          system-monitor.extensionUuid
        ];        
      };
      
      # Dash to Dock
      "org/gnome/shell/extensions/dash-to-dock" = {
        dock-position = "BOTTOM";
        dash-max-icon-size = 32;
        custom-theme-shrink = true;
      };
      
      # Dark Mode
      "org/gnome/desktop/interface" = {
         color-scheme = "prefer-dark";
         gtk-theme = "Adwaita-dark";
         icon-theme = "Adwaita";
         # Cursor
         cursor-theme = "Adwaita";
         cursor-size = 24;
         # Fonts
         font-name = "Adwaita Sans 11";
         document-font-name = "Adwaita Sans 11";
         monospace-font-name = "Adwaita Mono 11";
      };
      
      # Wallpaper      
      "org/gnome/desktop/background" = {
          picture-uri = "file://${config.home.homeDirectory}/Pictures/Wallpapers/blue-landscape.png";
          picture-uri-dark = "file://${config.home.homeDirectory}/Pictures/Wallpapers/blue-landscape.png";
          picture-options = "zoom";
       };
       
       # Lock Screen Wallpaper
       "org/gnome/desktop/screensaver" = {
          picture-uri = "file://${config.home.homeDirectory}/Pictures/Wallpapers/blue-landscape.png";
          picture-options = "zoom";
          };
    };
  };
}
